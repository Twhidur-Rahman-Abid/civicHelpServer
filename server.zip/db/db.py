from typing import Annotated, Generator
from sqlalchemy import create_engine
from sqlalchemy.orm import  sessionmaker, Session
from fastapi import Depends

DATABASE_URL =  "sqlite:///./cityfix.db"


is_sqlite = DATABASE_URL.startswith("sqlite")


connect_args = {"check_same_thread": False} if is_sqlite else {}


engine = create_engine(
    DATABASE_URL,
    connect_args=connect_args,
    echo=True, 
)


SessionLocal = sessionmaker(
    bind=engine,
    autocommit=False,
    autoflush=False,
)




def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# db dependency 
db_dependency = Annotated[Session, Depends(get_db)]